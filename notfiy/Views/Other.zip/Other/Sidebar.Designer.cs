﻿namespace notfiy.Views.Other
{
    partial class Sidebar
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Sidebar));
            kryptonPanel1 = new Krypton.Toolkit.KryptonPanel();
            kryptonLabel1 = new Krypton.Toolkit.KryptonLabel();
            kryptonLabel9 = new Krypton.Toolkit.KryptonLabel();
            kryptonPictureBox9 = new Krypton.Toolkit.KryptonPictureBox();
            kryptonPictureBox8 = new Krypton.Toolkit.KryptonPictureBox();
            kryptonPictureBox7 = new Krypton.Toolkit.KryptonPictureBox();
            kryptonPictureBox6 = new Krypton.Toolkit.KryptonPictureBox();
            kryptonPictureBox5 = new Krypton.Toolkit.KryptonPictureBox();
            kryptonPictureBox4 = new Krypton.Toolkit.KryptonPictureBox();
            kryptonPictureBox3 = new Krypton.Toolkit.KryptonPictureBox();
            kryptonPictureBox2 = new Krypton.Toolkit.KryptonPictureBox();
            kryptonPictureBox1 = new Krypton.Toolkit.KryptonPictureBox();
            kryptonLabel8 = new Krypton.Toolkit.KryptonLabel();
            kryptonLabel7 = new Krypton.Toolkit.KryptonLabel();
            kryptonLabel6 = new Krypton.Toolkit.KryptonLabel();
            kryptonLabel5 = new Krypton.Toolkit.KryptonLabel();
            kryptonLabel4 = new Krypton.Toolkit.KryptonLabel();
            kryptonLabel3 = new Krypton.Toolkit.KryptonLabel();
            kryptonLabel2 = new Krypton.Toolkit.KryptonLabel();
            ((System.ComponentModel.ISupportInitialize)kryptonPanel1).BeginInit();
            kryptonPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)kryptonPictureBox9).BeginInit();
            ((System.ComponentModel.ISupportInitialize)kryptonPictureBox8).BeginInit();
            ((System.ComponentModel.ISupportInitialize)kryptonPictureBox7).BeginInit();
            ((System.ComponentModel.ISupportInitialize)kryptonPictureBox6).BeginInit();
            ((System.ComponentModel.ISupportInitialize)kryptonPictureBox5).BeginInit();
            ((System.ComponentModel.ISupportInitialize)kryptonPictureBox4).BeginInit();
            ((System.ComponentModel.ISupportInitialize)kryptonPictureBox3).BeginInit();
            ((System.ComponentModel.ISupportInitialize)kryptonPictureBox2).BeginInit();
            ((System.ComponentModel.ISupportInitialize)kryptonPictureBox1).BeginInit();
            SuspendLayout();
            // 
            // kryptonPanel1
            // 
            kryptonPanel1.Controls.Add(kryptonLabel1);
            kryptonPanel1.Controls.Add(kryptonLabel9);
            kryptonPanel1.Controls.Add(kryptonPictureBox9);
            kryptonPanel1.Controls.Add(kryptonPictureBox8);
            kryptonPanel1.Controls.Add(kryptonPictureBox7);
            kryptonPanel1.Controls.Add(kryptonPictureBox6);
            kryptonPanel1.Controls.Add(kryptonPictureBox5);
            kryptonPanel1.Controls.Add(kryptonPictureBox4);
            kryptonPanel1.Controls.Add(kryptonPictureBox3);
            kryptonPanel1.Controls.Add(kryptonPictureBox2);
            kryptonPanel1.Controls.Add(kryptonPictureBox1);
            kryptonPanel1.Controls.Add(kryptonLabel8);
            kryptonPanel1.Controls.Add(kryptonLabel7);
            kryptonPanel1.Controls.Add(kryptonLabel6);
            kryptonPanel1.Controls.Add(kryptonLabel5);
            kryptonPanel1.Controls.Add(kryptonLabel4);
            kryptonPanel1.Controls.Add(kryptonLabel3);
            kryptonPanel1.Controls.Add(kryptonLabel2);
            kryptonPanel1.Location = new Point(0, 0);
            kryptonPanel1.Margin = new Padding(0);
            kryptonPanel1.Name = "kryptonPanel1";
            kryptonPanel1.Size = new Size(480, 1024);
            kryptonPanel1.StateNormal.Color1 = Color.FromArgb(51, 15, 126);
            kryptonPanel1.StateNormal.Color2 = Color.FromArgb(51, 15, 126);
            kryptonPanel1.TabIndex = 0;
            // 
            // kryptonLabel1
            // 
            kryptonLabel1.Location = new Point(182, 195);
            kryptonLabel1.Name = "kryptonLabel1";
            kryptonLabel1.Size = new Size(144, 46);
            kryptonLabel1.StateCommon.ShortText.Color1 = Color.White;
            kryptonLabel1.StateNormal.ShortText.Color1 = Color.White;
            kryptonLabel1.StateNormal.ShortText.Color2 = Color.White;
            kryptonLabel1.StateNormal.ShortText.Font = new Font("Microsoft Sans Serif", 26.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            kryptonLabel1.StateNormal.ShortText.Hint = Krypton.Toolkit.PaletteTextHint.AntiAlias;
            kryptonLabel1.TabIndex = 0;
            kryptonLabel1.Values.Text = "Catatan";
            kryptonLabel1.Click += kryptonLabel1_Click;
            // 
            // kryptonLabel9
            // 
            kryptonLabel9.Location = new Point(223, 74);
            kryptonLabel9.Name = "kryptonLabel9";
            kryptonLabel9.Size = new Size(151, 46);
            kryptonLabel9.StateCommon.ShortText.Color1 = Color.White;
            kryptonLabel9.StateNormal.ShortText.Color1 = Color.White;
            kryptonLabel9.StateNormal.ShortText.Color2 = Color.White;
            kryptonLabel9.StateNormal.ShortText.Font = new Font("Microsoft Sans Serif", 26.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            kryptonLabel9.StateNormal.ShortText.Hint = Krypton.Toolkit.PaletteTextHint.AntiAlias;
            kryptonLabel9.TabIndex = 17;
            kryptonLabel9.Values.Text = "Rafkyyy";
            // 
            // kryptonPictureBox9
            // 
            kryptonPictureBox9.Image = (Image)resources.GetObject("kryptonPictureBox9.Image");
            kryptonPictureBox9.Location = new Point(103, 45);
            kryptonPictureBox9.Name = "kryptonPictureBox9";
            kryptonPictureBox9.Size = new Size(92, 92);
            kryptonPictureBox9.SizeMode = PictureBoxSizeMode.AutoSize;
            kryptonPictureBox9.TabIndex = 16;
            kryptonPictureBox9.TabStop = false;
            // 
            // kryptonPictureBox8
            // 
            kryptonPictureBox8.Image = (Image)resources.GetObject("kryptonPictureBox8.Image");
            kryptonPictureBox8.Location = new Point(124, 658);
            kryptonPictureBox8.Name = "kryptonPictureBox8";
            kryptonPictureBox8.Size = new Size(40, 40);
            kryptonPictureBox8.SizeMode = PictureBoxSizeMode.AutoSize;
            kryptonPictureBox8.TabIndex = 15;
            kryptonPictureBox8.TabStop = false;
            // 
            // kryptonPictureBox7
            // 
            kryptonPictureBox7.Image = (Image)resources.GetObject("kryptonPictureBox7.Image");
            kryptonPictureBox7.Location = new Point(124, 594);
            kryptonPictureBox7.Name = "kryptonPictureBox7";
            kryptonPictureBox7.Size = new Size(40, 40);
            kryptonPictureBox7.SizeMode = PictureBoxSizeMode.AutoSize;
            kryptonPictureBox7.TabIndex = 14;
            kryptonPictureBox7.TabStop = false;
            // 
            // kryptonPictureBox6
            // 
            kryptonPictureBox6.Image = (Image)resources.GetObject("kryptonPictureBox6.Image");
            kryptonPictureBox6.Location = new Point(124, 530);
            kryptonPictureBox6.Name = "kryptonPictureBox6";
            kryptonPictureBox6.Size = new Size(40, 40);
            kryptonPictureBox6.SizeMode = PictureBoxSizeMode.AutoSize;
            kryptonPictureBox6.TabIndex = 13;
            kryptonPictureBox6.TabStop = false;
            // 
            // kryptonPictureBox5
            // 
            kryptonPictureBox5.Image = (Image)resources.GetObject("kryptonPictureBox5.Image");
            kryptonPictureBox5.Location = new Point(124, 468);
            kryptonPictureBox5.Name = "kryptonPictureBox5";
            kryptonPictureBox5.Size = new Size(40, 40);
            kryptonPictureBox5.SizeMode = PictureBoxSizeMode.AutoSize;
            kryptonPictureBox5.TabIndex = 12;
            kryptonPictureBox5.TabStop = false;
            // 
            // kryptonPictureBox4
            // 
            kryptonPictureBox4.Image = (Image)resources.GetObject("kryptonPictureBox4.Image");
            kryptonPictureBox4.Location = new Point(124, 399);
            kryptonPictureBox4.Name = "kryptonPictureBox4";
            kryptonPictureBox4.Size = new Size(40, 40);
            kryptonPictureBox4.SizeMode = PictureBoxSizeMode.AutoSize;
            kryptonPictureBox4.TabIndex = 11;
            kryptonPictureBox4.TabStop = false;
            // 
            // kryptonPictureBox3
            // 
            kryptonPictureBox3.Image = (Image)resources.GetObject("kryptonPictureBox3.Image");
            kryptonPictureBox3.Location = new Point(124, 331);
            kryptonPictureBox3.Name = "kryptonPictureBox3";
            kryptonPictureBox3.Size = new Size(40, 40);
            kryptonPictureBox3.SizeMode = PictureBoxSizeMode.AutoSize;
            kryptonPictureBox3.TabIndex = 10;
            kryptonPictureBox3.TabStop = false;
            // 
            // kryptonPictureBox2
            // 
            kryptonPictureBox2.Image = (Image)resources.GetObject("kryptonPictureBox2.Image");
            kryptonPictureBox2.Location = new Point(124, 267);
            kryptonPictureBox2.Name = "kryptonPictureBox2";
            kryptonPictureBox2.Size = new Size(40, 40);
            kryptonPictureBox2.SizeMode = PictureBoxSizeMode.AutoSize;
            kryptonPictureBox2.TabIndex = 9;
            kryptonPictureBox2.TabStop = false;
            // 
            // kryptonPictureBox1
            // 
            kryptonPictureBox1.Image = (Image)resources.GetObject("kryptonPictureBox1.Image");
            kryptonPictureBox1.Location = new Point(124, 195);
            kryptonPictureBox1.Name = "kryptonPictureBox1";
            kryptonPictureBox1.Size = new Size(40, 40);
            kryptonPictureBox1.SizeMode = PictureBoxSizeMode.AutoSize;
            kryptonPictureBox1.TabIndex = 8;
            kryptonPictureBox1.TabStop = false;
            // 
            // kryptonLabel8
            // 
            kryptonLabel8.Location = new Point(182, 658);
            kryptonLabel8.Name = "kryptonLabel8";
            kryptonLabel8.Size = new Size(152, 46);
            kryptonLabel8.StateNormal.ShortText.Color1 = Color.White;
            kryptonLabel8.StateNormal.ShortText.Color2 = Color.White;
            kryptonLabel8.StateNormal.ShortText.Font = new Font("Microsoft Sans Serif", 26.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            kryptonLabel8.StateNormal.ShortText.Hint = Krypton.Toolkit.PaletteTextHint.AntiAlias;
            kryptonLabel8.TabIndex = 7;
            kryptonLabel8.Values.Text = "Sampah";
            kryptonLabel8.Click += kryptonLabel8_Click;
            // 
            // kryptonLabel7
            // 
            kryptonLabel7.Location = new Point(182, 594);
            kryptonLabel7.Name = "kryptonLabel7";
            kryptonLabel7.Size = new Size(96, 46);
            kryptonLabel7.StateNormal.ShortText.Color1 = Color.White;
            kryptonLabel7.StateNormal.ShortText.Color2 = Color.White;
            kryptonLabel7.StateNormal.ShortText.Font = new Font("Microsoft Sans Serif", 26.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            kryptonLabel7.StateNormal.ShortText.Hint = Krypton.Toolkit.PaletteTextHint.AntiAlias;
            kryptonLabel7.TabIndex = 6;
            kryptonLabel7.Values.Text = "Draft";
            // 
            // kryptonLabel6
            // 
            kryptonLabel6.Location = new Point(182, 530);
            kryptonLabel6.Name = "kryptonLabel6";
            kryptonLabel6.Size = new Size(100, 46);
            kryptonLabel6.StateNormal.ShortText.Color1 = Color.White;
            kryptonLabel6.StateNormal.ShortText.Color2 = Color.White;
            kryptonLabel6.StateNormal.ShortText.Font = new Font("Microsoft Sans Serif", 26.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            kryptonLabel6.StateNormal.ShortText.Hint = Krypton.Toolkit.PaletteTextHint.AntiAlias;
            kryptonLabel6.TabIndex = 5;
            kryptonLabel6.Values.Text = "Arsip";
            // 
            // kryptonLabel5
            // 
            kryptonLabel5.Location = new Point(182, 468);
            kryptonLabel5.Name = "kryptonLabel5";
            kryptonLabel5.Size = new Size(167, 46);
            kryptonLabel5.StateNormal.ShortText.Color1 = Color.White;
            kryptonLabel5.StateNormal.ShortText.Color2 = Color.White;
            kryptonLabel5.StateNormal.ShortText.Font = new Font("Microsoft Sans Serif", 26.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            kryptonLabel5.StateNormal.ShortText.Hint = Krypton.Toolkit.PaletteTextHint.AntiAlias;
            kryptonLabel5.TabIndex = 4;
            kryptonLabel5.Values.Text = "Edit label";
            kryptonLabel5.Click += kryptonLabel5_Click;
            // 
            // kryptonLabel4
            // 
            kryptonLabel4.Location = new Point(182, 399);
            kryptonLabel4.Name = "kryptonLabel4";
            kryptonLabel4.Size = new Size(102, 46);
            kryptonLabel4.StateNormal.ShortText.Color1 = Color.White;
            kryptonLabel4.StateNormal.ShortText.Color2 = Color.White;
            kryptonLabel4.StateNormal.ShortText.Font = new Font("Microsoft Sans Serif", 26.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            kryptonLabel4.StateNormal.ShortText.Hint = Krypton.Toolkit.PaletteTextHint.AntiAlias;
            kryptonLabel4.TabIndex = 3;
            kryptonLabel4.Values.Text = "Diary";
            // 
            // kryptonLabel3
            // 
            kryptonLabel3.Location = new Point(182, 331);
            kryptonLabel3.Name = "kryptonLabel3";
            kryptonLabel3.Size = new Size(208, 46);
            kryptonLabel3.StateNormal.ShortText.Color1 = Color.White;
            kryptonLabel3.StateNormal.ShortText.Color2 = Color.White;
            kryptonLabel3.StateNormal.ShortText.Font = new Font("Microsoft Sans Serif", 26.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            kryptonLabel3.StateNormal.ShortText.Hint = Krypton.Toolkit.PaletteTextHint.AntiAlias;
            kryptonLabel3.TabIndex = 2;
            kryptonLabel3.Values.Text = "Health Note";
            kryptonLabel3.Click += kryptonLabel3_Click;
            // 
            // kryptonLabel2
            // 
            kryptonLabel2.Location = new Point(182, 267);
            kryptonLabel2.Name = "kryptonLabel2";
            kryptonLabel2.Size = new Size(176, 46);
            kryptonLabel2.StateDisabled.ShortText.Color1 = Color.White;
            kryptonLabel2.StateDisabled.ShortText.Color2 = Color.White;
            kryptonLabel2.StateDisabled.ShortText.Font = new Font("Microsoft Sans Serif", 21.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            kryptonLabel2.StateNormal.ShortText.Color1 = Color.White;
            kryptonLabel2.StateNormal.ShortText.Color2 = Color.White;
            kryptonLabel2.StateNormal.ShortText.Font = new Font("Microsoft Sans Serif", 26.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            kryptonLabel2.TabIndex = 1;
            kryptonLabel2.Values.Text = "To do List\r\n";
            kryptonLabel2.Click += kryptonLabel2_Click;
            // 
            // Sidebar
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            Controls.Add(kryptonPanel1);
            Name = "Sidebar";
            RightToLeft = RightToLeft.Yes;
            Size = new Size(480, 1024);
            Load += Sidebar_Load;
            ((System.ComponentModel.ISupportInitialize)kryptonPanel1).EndInit();
            kryptonPanel1.ResumeLayout(false);
            kryptonPanel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)kryptonPictureBox9).EndInit();
            ((System.ComponentModel.ISupportInitialize)kryptonPictureBox8).EndInit();
            ((System.ComponentModel.ISupportInitialize)kryptonPictureBox7).EndInit();
            ((System.ComponentModel.ISupportInitialize)kryptonPictureBox6).EndInit();
            ((System.ComponentModel.ISupportInitialize)kryptonPictureBox5).EndInit();
            ((System.ComponentModel.ISupportInitialize)kryptonPictureBox4).EndInit();
            ((System.ComponentModel.ISupportInitialize)kryptonPictureBox3).EndInit();
            ((System.ComponentModel.ISupportInitialize)kryptonPictureBox2).EndInit();
            ((System.ComponentModel.ISupportInitialize)kryptonPictureBox1).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private Krypton.Toolkit.KryptonPanel kryptonPanel1;
        private Krypton.Toolkit.KryptonLabel kryptonLabel1;
        private Krypton.Toolkit.KryptonLabel kryptonLabel2;
        private Krypton.Toolkit.KryptonLabel kryptonLabel4;
        private Krypton.Toolkit.KryptonLabel kryptonLabel3;
        private Krypton.Toolkit.KryptonLabel kryptonLabel5;
        private Krypton.Toolkit.KryptonLabel kryptonLabel8;
        private Krypton.Toolkit.KryptonLabel kryptonLabel7;
        private Krypton.Toolkit.KryptonLabel kryptonLabel6;
        private Krypton.Toolkit.KryptonPictureBox kryptonPictureBox1;
        private Krypton.Toolkit.KryptonPictureBox kryptonPictureBox6;
        private Krypton.Toolkit.KryptonPictureBox kryptonPictureBox5;
        private Krypton.Toolkit.KryptonPictureBox kryptonPictureBox4;
        private Krypton.Toolkit.KryptonPictureBox kryptonPictureBox3;
        private Krypton.Toolkit.KryptonPictureBox kryptonPictureBox2;
        private Krypton.Toolkit.KryptonPictureBox kryptonPictureBox9;
        private Krypton.Toolkit.KryptonPictureBox kryptonPictureBox8;
        private Krypton.Toolkit.KryptonPictureBox kryptonPictureBox7;
        private Krypton.Toolkit.KryptonLabel kryptonLabel9;
    }
}
